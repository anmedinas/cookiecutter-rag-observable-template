# Simulación de cliente LLM
