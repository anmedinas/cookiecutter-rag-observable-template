from rag_project.core.rag_pipeline import run_pipeline

if __name__ == "__main__":
    run_pipeline("¿Qué es OpenInference?")
