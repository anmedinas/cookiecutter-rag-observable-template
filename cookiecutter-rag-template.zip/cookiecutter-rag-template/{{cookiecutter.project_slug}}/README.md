# {{ cookiecutter.project_name }}

Este proyecto implementa un sistema RAG modular e instrumentado usando OpenTelemetry y OpenInference.
